package com.dio.orcamentoai.service;

import com.dio.orcamentoai.domain.Transacao;
import com.dio.orcamentoai.domain.TipoTransacao;
import com.dio.orcamentoai.dto.SaldoPorCategoriaResponse;
import com.dio.orcamentoai.repository.TransacaoRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class TransacaoService {

    private final TransacaoRepository repositorio;

    public TransacaoService(TransacaoRepository repositorio) {
        this.repositorio = repositorio;
    }

    public Transacao registrar(String descricao, BigDecimal valor, TipoTransacao tipo, String categoria) {
        if (valor == null || valor.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("O valor da transação deve ser maior que zero.");
        }
        if (categoria == null || categoria.isBlank()) {
            throw new IllegalArgumentException("A categoria da transação é obrigatória.");
        }
        Transacao transacao = new Transacao(descricao, valor, tipo, categoria, LocalDate.now());
        return repositorio.save(transacao);
    }

    public List<Transacao> listarTodas() {
        return repositorio.findAll();
    }

    public List<Transacao> consultarPorCategoria(String categoria) {
        return repositorio.findByCategoriaIgnoreCaseOrderByDataDesc(categoria);
    }

    public List<Transacao> consultarPorPeriodo(LocalDate inicio, LocalDate fim) {
        return repositorio.findByDataBetweenOrderByDataDesc(inicio, fim);
    }

    public BigDecimal calcularSaldo() {
        return repositorio.findAll().stream()
                .map(Transacao::getValorAssinado)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * Melhoria em relação ao projeto base: agrupa o saldo por categoria,
     * permitindo perguntas como "quanto eu já gastei com Mercado?".
     */
    public List<SaldoPorCategoriaResponse> calcularSaldoPorCategoria() {
        Map<String, BigDecimal> saldoPorCategoria = repositorio.findAll().stream()
                .collect(Collectors.groupingBy(
                        Transacao::getCategoria,
                        Collectors.reducing(BigDecimal.ZERO, Transacao::getValorAssinado, BigDecimal::add)
                ));

        return saldoPorCategoria.entrySet().stream()
                .map(entrada -> new SaldoPorCategoriaResponse(entrada.getKey(), entrada.getValue()))
                .sorted(Comparator.comparing(SaldoPorCategoriaResponse::categoria))
                .toList();
    }
}
