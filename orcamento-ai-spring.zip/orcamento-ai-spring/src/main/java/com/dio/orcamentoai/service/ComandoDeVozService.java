package com.dio.orcamentoai.service;

import com.dio.orcamentoai.dto.ComandoDeVozResponse;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.openai.OpenAiAudioSpeechModel;
import org.springframework.ai.openai.OpenAiAudioTranscriptionModel;
import org.springframework.ai.openai.audio.speech.SpeechPrompt;
import org.springframework.ai.openai.audio.speech.SpeechResponse;
import org.springframework.ai.openai.audio.transcription.AudioTranscriptionPrompt;
import org.springframework.ai.openai.audio.transcription.AudioTranscriptionResponse;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Base64;

/**
 * Orquestra o fluxo principal da API:
 * áudio -> texto (STT) -> intenção via IA + Tool Calling -> texto de resposta -> áudio (TTS).
 */
@Service
public class ComandoDeVozService {

    private final ChatClient chatClient;
    private final OpenAiAudioTranscriptionModel modeloTranscricao;
    private final OpenAiAudioSpeechModel modeloVoz;

    public ComandoDeVozService(ChatClient chatClient,
                                OpenAiAudioTranscriptionModel modeloTranscricao,
                                OpenAiAudioSpeechModel modeloVoz) {
        this.chatClient = chatClient;
        this.modeloTranscricao = modeloTranscricao;
        this.modeloVoz = modeloVoz;
    }

    public ComandoDeVozResponse processar(MultipartFile arquivoDeAudio) {
        String transcricao = transcrever(arquivoDeAudio);
        String respostaTexto = interpretarComIA(transcricao);
        String respostaAudioBase64 = gerarAudioDeResposta(respostaTexto);

        return new ComandoDeVozResponse(transcricao, respostaTexto, respostaAudioBase64);
    }

    private String transcrever(MultipartFile arquivoDeAudio) {
        try {
            ByteArrayResource recurso = new ByteArrayResource(arquivoDeAudio.getBytes()) {
                @Override
                public String getFilename() {
                    return arquivoDeAudio.getOriginalFilename();
                }
            };
            AudioTranscriptionPrompt prompt = new AudioTranscriptionPrompt(recurso);
            AudioTranscriptionResponse resposta = modeloTranscricao.call(prompt);
            return resposta.getResult().getOutput();
        } catch (IOException e) {
            throw new IllegalStateException("Não foi possível ler o arquivo de áudio enviado.", e);
        }
    }

    private String interpretarComIA(String textoTranscrito) {
        return chatClient.prompt()
                .user(textoTranscrito)
                .call()
                .content();
    }

    private String gerarAudioDeResposta(String texto) {
        SpeechPrompt prompt = new SpeechPrompt(texto);
        SpeechResponse resposta = modeloVoz.call(prompt);
        byte[] audioBytes = resposta.getResult().getOutput();
        return Base64.getEncoder().encodeToString(audioBytes);
    }
}
