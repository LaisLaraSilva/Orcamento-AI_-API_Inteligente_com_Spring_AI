package com.dio.orcamentoai.dto;

import com.dio.orcamentoai.domain.TipoTransacao;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

/**
 * Validações adicionadas como melhoria do projeto base:
 * - valor deve ser maior que zero;
 * - descrição, categoria e tipo são obrigatórios.
 */
public record TransacaoRequest(

        @NotBlank(message = "A descrição é obrigatória.")
        String descricao,

        @NotNull(message = "O valor é obrigatório.")
        @DecimalMin(value = "0.01", message = "O valor deve ser maior que zero.")
        BigDecimal valor,

        @NotNull(message = "O tipo (RECEITA ou DESPESA) é obrigatório.")
        TipoTransacao tipo,

        @NotBlank(message = "A categoria é obrigatória.")
        String categoria
) {
}
