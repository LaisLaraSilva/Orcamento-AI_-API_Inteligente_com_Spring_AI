package com.dio.orcamentoai.tools;

import com.dio.orcamentoai.domain.Transacao;
import com.dio.orcamentoai.domain.TipoTransacao;
import com.dio.orcamentoai.dto.SaldoPorCategoriaResponse;
import com.dio.orcamentoai.service.TransacaoService;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Funções reais da aplicação expostas para o modelo de IA via Tool Calling.
 * O ChatClient decide sozinho qual (ou quais) destes métodos chamar,
 * de acordo com a intenção identificada no comando de voz transcrito.
 */
@Component
public class FinanceiroTools {

    private final TransacaoService transacaoService;
    private static final DateTimeFormatter FORMATO_DATA = DateTimeFormatter.ISO_LOCAL_DATE;

    public FinanceiroTools(TransacaoService transacaoService) {
        this.transacaoService = transacaoService;
    }

    @Tool(description = "Registra uma nova transação financeira (receita ou despesa) com descrição, "
            + "valor em reais, tipo (RECEITA ou DESPESA) e categoria (ex: Mercado, Salário, Transporte).")
    public String registrarTransacao(String descricao, double valor, String tipo, String categoria) {
        try {
            TipoTransacao tipoTransacao = TipoTransacao.valueOf(tipo.trim().toUpperCase());
            Transacao transacao = transacaoService.registrar(
                    descricao, BigDecimal.valueOf(valor), tipoTransacao, categoria);
            return "Transação registrada: %s de R$ %.2f em '%s' no dia %s.".formatted(
                    tipoTransacao == TipoTransacao.RECEITA ? "receita" : "despesa",
                    transacao.getValor(),
                    transacao.getCategoria(),
                    transacao.getData().format(FORMATO_DATA));
        } catch (IllegalArgumentException e) {
            return "Não foi possível registrar a transação: " + e.getMessage();
        }
    }

    @Tool(description = "Consulta o saldo atual, somando todas as receitas e subtraindo todas as despesas.")
    public String consultarSaldo() {
        BigDecimal saldo = transacaoService.calcularSaldo();
        return "O saldo atual é de R$ %.2f.".formatted(saldo);
    }

    @Tool(description = "Consulta o saldo agrupado por categoria, mostrando quanto entrou ou saiu em cada uma.")
    public String consultarSaldoPorCategoria() {
        List<SaldoPorCategoriaResponse> saldos = transacaoService.calcularSaldoPorCategoria();
        if (saldos.isEmpty()) {
            return "Ainda não há transações registradas.";
        }
        return saldos.stream()
                .map(s -> "%s: R$ %.2f".formatted(s.categoria(), s.saldo()))
                .collect(Collectors.joining("; "));
    }

    @Tool(description = "Lista as transações de uma categoria específica, como Mercado ou Transporte.")
    public String consultarTransacoesPorCategoria(String categoria) {
        List<Transacao> transacoes = transacaoService.consultarPorCategoria(categoria);
        if (transacoes.isEmpty()) {
            return "Nenhuma transação encontrada na categoria '" + categoria + "'.";
        }
        return transacoes.stream()
                .map(t -> "%s: R$ %.2f (%s) em %s".formatted(
                        t.getDescricao(), t.getValor(), t.getTipo(), t.getData().format(FORMATO_DATA)))
                .collect(Collectors.joining("; "));
    }

    @Tool(description = "Lista as transações entre duas datas no formato yyyy-MM-dd (ano-mês-dia).")
    public String consultarTransacoesPorPeriodo(String dataInicio, String dataFim) {
        LocalDate inicio = LocalDate.parse(dataInicio, FORMATO_DATA);
        LocalDate fim = LocalDate.parse(dataFim, FORMATO_DATA);
        List<Transacao> transacoes = transacaoService.consultarPorPeriodo(inicio, fim);
        if (transacoes.isEmpty()) {
            return "Nenhuma transação encontrada entre " + dataInicio + " e " + dataFim + ".";
        }
        return transacoes.stream()
                .map(t -> "%s: R$ %.2f (%s) em %s".formatted(
                        t.getDescricao(), t.getValor(), t.getTipo(), t.getData().format(FORMATO_DATA)))
                .collect(Collectors.joining("; "));
    }
}
