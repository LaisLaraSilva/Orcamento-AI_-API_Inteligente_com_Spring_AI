package com.dio.orcamentoai.controller;

import com.dio.orcamentoai.dto.ComandoDeVozResponse;
import com.dio.orcamentoai.service.ComandoDeVozService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/comandos-de-voz")
public class ComandoDeVozController {

    private final ComandoDeVozService comandoDeVozService;

    public ComandoDeVozController(ComandoDeVozService comandoDeVozService) {
        this.comandoDeVozService = comandoDeVozService;
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ComandoDeVozResponse processarComando(@RequestParam("audio") MultipartFile audio) {
        return comandoDeVozService.processar(audio);
    }
}
