package com.dio.orcamentoai.dto;

import java.math.BigDecimal;

public record SaldoPorCategoriaResponse(String categoria, BigDecimal saldo) {
}
