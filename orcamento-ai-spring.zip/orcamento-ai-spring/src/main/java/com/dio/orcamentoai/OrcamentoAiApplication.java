package com.dio.orcamentoai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrcamentoAiApplication {

    public static void main(String[] args) {
        SpringApplication.run(OrcamentoAiApplication.class, args);
    }
}
