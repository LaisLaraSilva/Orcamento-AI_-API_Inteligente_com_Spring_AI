package com.dio.orcamentoai.controller;

import com.dio.orcamentoai.dto.SaldoPorCategoriaResponse;
import com.dio.orcamentoai.dto.TransacaoRequest;
import com.dio.orcamentoai.dto.TransacaoResponse;
import com.dio.orcamentoai.service.TransacaoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/transacoes")
public class TransacaoController {

    private final TransacaoService transacaoService;

    public TransacaoController(TransacaoService transacaoService) {
        this.transacaoService = transacaoService;
    }

    @PostMapping
    public ResponseEntity<TransacaoResponse> registrar(@Valid @RequestBody TransacaoRequest request) {
        var transacao = transacaoService.registrar(
                request.descricao(), request.valor(), request.tipo(), request.categoria());
        return ResponseEntity.status(HttpStatus.CREATED).body(TransacaoResponse.deEntidade(transacao));
    }

    @GetMapping
    public List<TransacaoResponse> listarTodas() {
        return transacaoService.listarTodas().stream()
                .map(TransacaoResponse::deEntidade)
                .toList();
    }

    @GetMapping("/saldo")
    public BigDecimal saldo() {
        return transacaoService.calcularSaldo();
    }

    @GetMapping("/saldo-por-categoria")
    public List<SaldoPorCategoriaResponse> saldoPorCategoria() {
        return transacaoService.calcularSaldoPorCategoria();
    }

    @GetMapping("/categoria/{categoria}")
    public List<TransacaoResponse> porCategoria(@PathVariable String categoria) {
        return transacaoService.consultarPorCategoria(categoria).stream()
                .map(TransacaoResponse::deEntidade)
                .toList();
    }

    @GetMapping("/periodo")
    public List<TransacaoResponse> porPeriodo(
            @RequestParam("inicio") String inicio,
            @RequestParam("fim") String fim) {
        return transacaoService.consultarPorPeriodo(LocalDate.parse(inicio), LocalDate.parse(fim)).stream()
                .map(TransacaoResponse::deEntidade)
                .toList();
    }
}
