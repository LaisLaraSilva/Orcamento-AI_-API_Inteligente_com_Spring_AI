package com.dio.orcamentoai.dto;

public record ComandoDeVozResponse(
        String transcricao,
        String respostaTexto,
        String respostaAudioBase64
) {
}
