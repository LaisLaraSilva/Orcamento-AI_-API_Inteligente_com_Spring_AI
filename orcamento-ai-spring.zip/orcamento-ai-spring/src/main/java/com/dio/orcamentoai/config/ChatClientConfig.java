package com.dio.orcamentoai.config;

import com.dio.orcamentoai.tools.FinanceiroTools;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.memory.InMemoryChatMemory;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ChatClientConfig {

    private static final String PROMPT_SISTEMA = """
            Você é o assistente financeiro do app Orçamento AI.
            Sua função é entender comandos de voz transcritos sobre transações financeiras
            (receitas e despesas) e executar a ação correta usando as ferramentas disponíveis.

            Regras:
            - Sempre que o usuário disser algo como "gastei", "recebi", "paguei" ou "ganhei",
              use a ferramenta de registro de transação.
            - Sempre que o usuário perguntar sobre saldo, gastos ou receitas, use a ferramenta
              de consulta apropriada em vez de responder de memória.
            - Se faltar alguma informação obrigatória (valor ou categoria), peça essa informação
              educadamente antes de registrar a transação.
            - Responda sempre em português, de forma curta e direta, como se estivesse falando
              em voz alta para o usuário.
            """;

    @Bean
    public ChatClient chatClient(OpenAiChatModel modeloChat, FinanceiroTools financeiroTools) {
        return ChatClient.builder(modeloChat)
                .defaultSystem(PROMPT_SISTEMA)
                .defaultTools(financeiroTools)
                .defaultAdvisors(MessageChatMemoryAdvisor.builder(new InMemoryChatMemory()).build())
                .build();
    }
}
