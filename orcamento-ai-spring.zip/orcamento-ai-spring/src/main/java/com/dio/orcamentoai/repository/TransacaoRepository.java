package com.dio.orcamentoai.repository;

import com.dio.orcamentoai.domain.Transacao;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface TransacaoRepository extends JpaRepository<Transacao, Long> {

    List<Transacao> findByCategoriaIgnoreCaseOrderByDataDesc(String categoria);

    List<Transacao> findByDataBetweenOrderByDataDesc(LocalDate inicio, LocalDate fim);
}
