package com.dio.orcamentoai.dto;

import com.dio.orcamentoai.domain.Transacao;
import com.dio.orcamentoai.domain.TipoTransacao;

import java.math.BigDecimal;
import java.time.LocalDate;

public record TransacaoResponse(
        Long id,
        String descricao,
        BigDecimal valor,
        TipoTransacao tipo,
        String categoria,
        LocalDate data
) {
    public static TransacaoResponse deEntidade(Transacao transacao) {
        return new TransacaoResponse(
                transacao.getId(),
                transacao.getDescricao(),
                transacao.getValor(),
                transacao.getTipo(),
                transacao.getCategoria(),
                transacao.getData()
        );
    }
}
