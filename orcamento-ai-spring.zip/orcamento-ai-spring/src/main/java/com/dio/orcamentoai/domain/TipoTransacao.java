package com.dio.orcamentoai.domain;

public enum TipoTransacao {
    RECEITA,
    DESPESA
}
