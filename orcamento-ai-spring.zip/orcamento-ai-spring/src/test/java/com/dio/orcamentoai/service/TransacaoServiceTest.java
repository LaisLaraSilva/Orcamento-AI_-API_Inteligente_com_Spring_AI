package com.dio.orcamentoai.service;

import com.dio.orcamentoai.domain.TipoTransacao;
import com.dio.orcamentoai.domain.Transacao;
import com.dio.orcamentoai.repository.TransacaoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class TransacaoServiceTest {

    private TransacaoRepository repositorio;
    private TransacaoService service;

    @BeforeEach
    void configurar() {
        repositorio = mock(TransacaoRepository.class);
        service = new TransacaoService(repositorio);
    }

    @Test
    void deveRegistrarTransacaoValida() {
        when(repositorio.save(any(Transacao.class))).thenAnswer(chamada -> chamada.getArgument(0));

        Transacao transacao = service.registrar(
                "Mercado do mês", BigDecimal.valueOf(250.00), TipoTransacao.DESPESA, "Mercado");

        assertEquals("Mercado", transacao.getCategoria());
        assertEquals(TipoTransacao.DESPESA, transacao.getTipo());
        assertEquals(BigDecimal.valueOf(250.00), transacao.getValor());
    }

    @Test
    void naoDeveRegistrarTransacaoComValorZeroOuNegativo() {
        assertThrows(IllegalArgumentException.class, () ->
                service.registrar("Teste", BigDecimal.ZERO, TipoTransacao.RECEITA, "Salário"));

        assertThrows(IllegalArgumentException.class, () ->
                service.registrar("Teste", BigDecimal.valueOf(-10), TipoTransacao.RECEITA, "Salário"));
    }

    @Test
    void naoDeveRegistrarTransacaoSemCategoria() {
        assertThrows(IllegalArgumentException.class, () ->
                service.registrar("Teste", BigDecimal.TEN, TipoTransacao.RECEITA, " "));
    }

    @Test
    void deveCalcularSaldoSomandoReceitasESubtraindoDespesas() {
        Transacao receita = new Transacao("Salário", BigDecimal.valueOf(3000), TipoTransacao.RECEITA,
                "Salário", LocalDate.now());
        Transacao despesa = new Transacao("Mercado", BigDecimal.valueOf(400), TipoTransacao.DESPESA,
                "Mercado", LocalDate.now());

        when(repositorio.findAll()).thenReturn(List.of(receita, despesa));

        BigDecimal saldo = service.calcularSaldo();

        assertEquals(BigDecimal.valueOf(2600), saldo);
    }

    @Test
    void deveAgruparSaldoPorCategoria() {
        Transacao receita = new Transacao("Salário", BigDecimal.valueOf(3000), TipoTransacao.RECEITA,
                "Salário", LocalDate.now());
        Transacao despesa1 = new Transacao("Mercado dia 1", BigDecimal.valueOf(150), TipoTransacao.DESPESA,
                "Mercado", LocalDate.now());
        Transacao despesa2 = new Transacao("Mercado dia 2", BigDecimal.valueOf(100), TipoTransacao.DESPESA,
                "Mercado", LocalDate.now());

        when(repositorio.findAll()).thenReturn(List.of(receita, despesa1, despesa2));

        var saldosPorCategoria = service.calcularSaldoPorCategoria();

        assertEquals(2, saldosPorCategoria.size());
        saldosPorCategoria.forEach(saldo -> {
            if (saldo.categoria().equals("Mercado")) {
                assertEquals(BigDecimal.valueOf(-250), saldo.saldo());
            }
            if (saldo.categoria().equals("Salário")) {
                assertEquals(BigDecimal.valueOf(3000), saldo.saldo());
            }
        });
    }
}
